<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/tastyrecipes/db.php';

$name = $_POST['name'];
$path = "/tastyrecipes/uploads/" . $_FILES['file']['name'];
move_uploaded_file($_FILES['file']['tmp_name'], $_SERVER["DOCUMENT_ROOT"] . $path);

$desc = $_POST['desc'];
$pdo->query("INSERT INTO recipes (name, short_description, image) VALUES ('$name', '$desc', '$path')");

header('Location: /tastyrecipes/admin/index.php');