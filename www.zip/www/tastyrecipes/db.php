<?php

$data = 'mysql:host=database;dbname=docker';
return new PDO($data, username: 'docker', password: 'docker');