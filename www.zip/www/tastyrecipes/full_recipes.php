<?php
$pdo = require $_SERVER['DOCUMENT_ROOT'] . '/tastyrecipes/db.php';
$id = $_GET['id'];
$cat = $_GET['cat'];

$recipes = $pdo->query("SELECT * FROM recipes WHERE id = '$id'")->fetchall(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php foreach ($recipes as $item): ?>
    <p><?=$item['name']?> - название</p>
        <img src="<?=$item['image']?>" alt="">
    <p><?=$item['short_description']?> - описание</p>
    <p><?=$item['recipe']?> - рецепт</p>
    <p><?=$item['rating']?> - рейтинг</p>
    <p><?=$item['cooking_time']?> - время приготовления</p>
    <p><?=$cat?> - категория</p>
    <?php endforeach;?>
</body>
</html>
